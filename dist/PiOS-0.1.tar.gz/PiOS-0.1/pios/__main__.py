
from argparse import ArgumentParser
from pios import version
from socket import g

def check_for_updates():
    pass


def check_for_internet():


if __name__ == '__main__':
    parser = ArgumentParser(description="PiOS boot manager. This boot manager allows the user to run PiOS with other"
                                        "configurations", fromfile_prefix_chars="@")

    parser.version = f"PiOS ({version})"

    parser.add_argument("-f", "--operating-system", help="Specify a Operating System to load and run",
                        default="pios")
    parser.add_argument("-c", "--check-upgrade", help="Check for upgrades", action="store_true")
    parser.add_argument("-v", "--version", action="version")

    args = parser.parse_args()

    if args.check_upgrade:


